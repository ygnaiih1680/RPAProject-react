import React from 'react'
import {CSpinner} from "@coreui/react";

export const Loading = () => <span className='d-flex justify-content-center align-content-center'><CSpinner color='primary'/></span>